# 🌌 Wonder Space - Website Source Code

මෙය **Wonder Space** YouTube චැනලය සඳහා නිර්මාණය කරන ලද නිල වෙබ් අඩවියේ මූලාශ්‍ර කේතයයි (Source Code).

## 🚀 තාක්ෂණික මෙවලම් (Tech Stack)
* **Frontend:** React 19, TypeScript, Tailwind CSS v4, Framer Motion (for animations)
* **Backend:** Vercel Serverless Functions (`api/` directory)
* **Database:** Supabase (Postgres)

---

## 🛠️ පරිගණකයේ ස්ථාපනය කර ක්‍රියාත්මක කරන ආකාරය (Local Setup)

ඔබේ පරිගණකයේ මෙම වෙබ් අඩවිය ක්‍රියාත්මක කිරීමට පහත පියවර අනුගමනය කරන්න:

### 1. Node.js ස්ථාපනය කරන්න
ඔබේ පරිගණකයේ Node.js ස්ථාපනය කර නොමැති නම් [nodejs.org](https://nodejs.org/) වෙතින් එය බාගත කර ස්ථාපනය කර ගන්න.

### 2. Dependencies ස්ථාපනය කරන්න
ප්‍රධාන ෆෝල්ඩරය තුළ (Project Root) Terminal එකක් විවෘත කර පහත විධානය ක්‍රියාත්මක කරන්න:
```bash
npm install
```

### 3. Environment Variables සැකසීම
වෙබ් අඩවිය සජීවීව දත්ත සමුදාය (Database) සමඟ සම්බන්ධ වීමට නම් `.env` ගොනුවක් සෑදිය යුතුය. ප්‍රධාන ෆෝල්ඩරය තුළ `.env` නමින් නව ගොනුවක් සාදා එහි පහත ආකාරයට ඔබේ Supabase යතුරු (Keys) ඇතුළත් කරන්න:

```env
VITE_SUPABASE_URL=ඔබේ_SUPABASE_PROJECT_URL
VITE_SUPABASE_ANON_KEY=ඔබේ_SUPABASE_ANON_KEY
NEXT_PUBLIC_SUPABASE_URL=ඔබේ_SUPABASE_PROJECT_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=ඔබේ_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=ඔබේ_SUPABASE_SERVICE_ROLE_KEY
```

### 4. වෙබ් අඩවිය ක්‍රියාත්මක කරන්න (Development Mode)
පහත විධානය මඟින් ඔබේ පරිගණකයේ වෙබ් අඩවිය ධාවනය කරන්න:
```bash
npm run dev
```
දැන් බ්‍රවුසරයේ `http://localhost:5173` වෙත ගොස් වෙබ් අඩවිය නැරඹිය හැක.

### 5. Build කිරීම (Production)
වෙබ් අඩවිය සර්වර් එකකට දැමීමට පෙර Build කර ගැනීමට:
```bash
npm run build
```

---

## 📂 ෆෝල්ඩර ව්‍යුහය (Folder Structure)
* `src/components/` - වෙබ් අඩවියේ ඇති සියලුම කොටස් (Navbar, FactCard, PlaceCard, VideoHub, QuizGame, TheoriesBoard, AdminPanel)
* `src/contexts/` - භාෂා පරිවර්තන පාලනය (Language Context - English / Sinhala)
* `api/` - දත්ත සමුදාය සමඟ ගනුදෙනු කරන Vercel Serverless Backend Routes
* `public/` - වෙබ් අඩවියේ පින්තූර, Favicon සහ වෙනත් පොදු ගොනු

---

## 🔑 පරිපාලක මුරපදය (Admin Passcode)
වෙබ් අඩවියේ ඇති "Creator Studio" (පරිපාලක පුවරුව) වෙත ඇතුළු වීමට ඇති රහස් මුරපදය:
👉 **`wonder2025`**

---
💜 **Wonder Space** චැනල් එකට අපෙන් සුභ පැතුම්!
